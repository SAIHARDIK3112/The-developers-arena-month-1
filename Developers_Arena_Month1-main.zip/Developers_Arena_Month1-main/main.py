from src.week1_basics import week1_demo
from src.week2_data_structures import week2_demo
from src.week3_numpy_pandas import week3_demo
from src.week4_visualization import week4_demo

def main():
    print("MONTH 1 - PYTHON & DATA SCIENCE TASKS\n")

    week1_demo()
    week2_demo()
    week3_demo()
    week4_demo()

if __name__ == "__main__":
    main()

def average_temperature(temperatures):
    return sum(temperatures) / len(temperatures)


def week1_demo():
    print("\nWeek 1: Python Basics")

    temperatures = [30, 32, 29, 35, 31]
    avg_temp = average_temperature(temperatures)

    print("Temperatures:", temperatures)
    print("Average Temperature:", avg_temp)

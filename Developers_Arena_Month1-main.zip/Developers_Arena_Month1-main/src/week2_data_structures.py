def remove_duplicates(data):
    return list(set(data))


def week2_demo():
    print("\nWeek 2: Data Structures")

    raw_data = [10, 20, 20, 30, 40, 40, 50]
    cleaned_data = remove_duplicates(raw_data)

    print("Original Data:", raw_data)
    print("Cleaned Data:", cleaned_data)

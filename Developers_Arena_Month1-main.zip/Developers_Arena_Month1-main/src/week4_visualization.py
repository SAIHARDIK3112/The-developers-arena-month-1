import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


def week4_demo():
    print("\nWeek 4: Data Visualization")

    df = pd.read_csv("data/sales_data.csv")

    plt.figure()
    sns.barplot(x="product", y="price", data=df)
    plt.title("Product Price Comparison")

    plt.savefig("screenshots/week4_plot.png")
    plt.show()

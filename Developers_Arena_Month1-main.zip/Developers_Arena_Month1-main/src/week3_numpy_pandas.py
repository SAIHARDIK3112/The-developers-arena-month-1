import pandas as pd


def week3_demo():
    print("\nWeek 3: NumPy & Pandas")

    df = pd.read_csv("data/sales_data.csv")
    df["total"] = df["price"] * df["quantity"]

    print(df)
    print("Average Sale Value:", df["total"].mean())
